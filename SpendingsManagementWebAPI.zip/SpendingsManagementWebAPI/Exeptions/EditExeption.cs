﻿namespace SpendingsManagementWebAPI.Exeptions
{
    public class EditExeption : Exception
    {
        public EditExeption(string message) : base(message)
        {
            
        }
    }
}
